<link rel="stylesheet" href="<?php echo plugin_dir_url(__FILE__); ?>style.css" type="text/css" />
<div class="payment-form">
	<form action="https://sep.shaparak.ir/payment.aspx" method="post">
		<table width="100%">
			<tr>
				<td><?php _e('نام', 'Sep'); ?></td>
				<td>
					<input type="text" name="payer_name" class="Sep-input" value="<?php echo $current_user->display_name; ?>"/>
					<span class="description-require">*</span>
				</td>
			</tr>

			<tr>
				<td><?php _e('ايميل', 'Sep'); ?></td>
				<td>
					<input type="text" name="payer_email" dir="ltr" class="Sep-input" value="<?php echo $current_user->user_email; ?>"/>
					<span class="description-require">*</span>
				</td>
			</tr>

			<tr>
				<td><?php _e('شمراه همراه', 'Sep'); ?></td>
				<td>
					<input type="text" name="payer_mobile" dir="ltr" value="09" class="Sep-input"/>
					<span class="description-require">*</span>
				</td>
			</tr>

			<tr>
				<td><?php _e('مبلغ (ریال)', 'Sep'); ?></td>
				<td>
					<input type="text" name="Amount" dir="ltr" class="Sep-input"/>
					<span class="description-require">*</span>
					
						
				</td>
			</tr>	
			
			<tr>
				<td><?php _e('شماره خريد', 'Sep'); ?></td>
				<td>
					<input type="text" name="ResNum" dir="ltr" class="Sep-input"/ value="<?php echo preg_replace("/[^0-9]/", "", uniqid()); ?>">
					<span class="description-require">*</span>
				</td>
			</tr>

			<tr>
				<td colspan="2">
					<input type="submit" name="submit_payment" value="<?php _e('پرداخت', 'Sep'); ?>" class="Sep-submit"/>
				</td>
			</tr>
		</table>

			<input type="hidden" name="RedirectURL" value="<?php echo get_option('return_url'); ?>"/>
			<input type="hidden"  name="MID" value="<?php echo get_option('MerchantID'); ?>"/>
	</form>
</div>

