<div class="wrap">
	<h2><?php _e('تنظیمات ماژول', 'Sep'); ?></h2>
	<form method="post" action="options.php">
		<table class="form-table">
			<?php wp_nonce_field('update-options');?>
			<tr><th colspan="2"><h3><?php _e('اطلاعات عمومی', 'Sep'); ?></h4></th></tr>
			<tr>
				<td width="20%"><?php _e('آی پی سرور:', 'Sep'); ?></td>
				<td>
					<code><?php echo $_SERVER['SERVER_ADDR']; ?></code>
					<br /><span style="font-size: 10px"><?php _e('آی پی سرور شما برای اعلام جهت دسترسی', 'Sep'); ?></span>
				</td>
			</tr>
			<tr>
				<td width="20%"><?php _e('کد پذیرنده:', 'Sep'); ?></td>
				<td>
					<input type="text" dir="ltr" name="MerchantID" value="<?php echo get_option('MerchantID'); ?>"/>
					<br /><span style="font-size: 10px"><?php _e('کد پذیرنده', 'Sep'); ?></span>
				</td>
			</tr>
			<tr>
				<td width="20%"><?php _e('رمز عبور:', 'Sep'); ?></td>
				<td>
					<input type="text" dir="ltr" name="port_password" value="<?php echo get_option('port_password'); ?>"/>
					<br /><span style="font-size: 10px"><?php _e('رمز عبور پذیرنده', 'Sep'); ?></span>
				</td>
			</tr>
			<tr>
				<td width="20%"><?php _e('آدرس صفحه نتیجه:', 'Sep'); ?></td>
				<td>
					<input type="text" dir="ltr" name="return_url" value="<?php echo get_option('return_url'); ?>"/>
					<br /><span style="font-size: 10px"><?php _e('آدرس صفحه بازگشت', 'Sep'); ?></span>
				</td>
			</tr>
			<tr>
				<td>
					<p class="submit">
					<input type="hidden" name="action" value="update" />
					<input type="hidden" name="page_options" value="MerchantID,port_password,return_url" />
					<input type="submit" class="button-primary" name="Submit" value="به روز رساني" />
					</p>
				</td>
			</tr>
		</table>
	</form>
</div>