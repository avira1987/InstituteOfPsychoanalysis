<?php
/*
Plugin Name: Saman-gateway
Plugin URI: 
Description: Saman gateway for wordpress To use plagin shortcode [sep_module] enjoy it!
Version: 1.2
Author: Amin - Rahimi
Author URI: 
License: GPL2
*/
	include_once('inc/Sep.class.php');
	$Sep = new Sep;

	if(get_option('MerchantID') && get_option('port_password')) {
		$Sep->MerchantID = get_option('MerchantID');
		$Sep->Password = get_option('port_password');
	}

	function Sep_menu() {
		if (function_exists('add_options_page')) {
			add_menu_page(__('Saman gateway', 'Sep'), __('Saman gateway', 'Sep'), 'manage_options', 'Amin-Saman/setting.php', 'Sep_menupage', plugin_dir_url( __FILE__ ).'/images/Saman_favicon.png');
			add_submenu_page('Amin-Saman/setting.php', __('Sep Setting', 'Saman gateway'), __('Sep Setting', 'Saman gateway'), 'manage_options', 'Amin-Saman/setting.php', 'Sep_menupage');
		}
	}
	add_action('admin_menu', 'Sep_menu');

	function Sep_menupage() {
		if (!current_user_can('manage_options')) {
			wp_die(__('You do not have sufficient permissions to access this page.', 'Sep'));
		}

		settings_fields('Sep_options');
		function register_Sep() {
			register_setting('Sep_options', 'MerchantID');
			register_setting('Sep_options', 'port_password');
		}

		include_once('setting.php');
	}	
	
	function sep_form(){
		global $current_user, $Sep;		
		include_once('inc/form.php');
		$state = $_POST['State'];

		  if(empty($state))
		  {
		  
		  }else if($state!="OK")
		  {
			echo("<p class='error-payment'>عملیات ناموفق</p>");
		  }else{
				 $result=$Sep->Verify();
				 if( $result <= 0 ){
					 echo '<p class="error-payment">ویرایفای انجام نشد</p>' ;
					 echo $result ;
					 echo '</p>';
				 }
				else
				{
					 echo '<p class="success-payment">تراکنش با موفقیت انجام شد<br/> مبلغ :';
					 echo $result ;
					 echo ' ریال</p>';
				 }
		  }		
	}	
	add_shortcode('sep_module', 'sep_form');
	add_filter('widget_text', 'do_shortcode');
?>