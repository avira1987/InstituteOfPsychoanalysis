﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Sep.PGA_ASPNET.Default" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <table>
                <tr>
                    <td>RedirectURL</td>
                    <td><asp:TextBox runat="server" id="RedirectURL" value="http://localhost:7428/result.aspx" ></asp:TextBox></td>
                </tr>
                <tr>
                    <td>MID</td>
                      <td><asp:TextBox runat="server" id="MID" value="2765" ></asp:TextBox></td>
                </tr>
                <tr>
                    <td>ResNum</td>
                       <td><asp:TextBox runat="server" id="ResNum" value="" ></asp:TextBox></td>
                </tr>

                <tr>
                    <td>Amount</td>
                       <td><asp:TextBox runat="server" id="amount" value="1000" ></asp:TextBox></td>
                </tr>

                 <tr>
                    <td colspan="2" align="center"><asp:Button runat="server" ID="btnSend" OnClick="btnSend_Click"  Text="ارسال اطلاعات" /></td>                     
                </tr>
            </table>
        </div>
    </form>
</body>
</html>
