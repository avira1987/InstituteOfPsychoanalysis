﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sep.PGA_ASPNET
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
                ResNum.Text = CreateResnum().ToString();
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            NameValueCollection datacollection = new NameValueCollection();


            datacollection.Add("ResNum", CreateResnum().ToString());

            datacollection.Add("MID", MID.Text);

            datacollection.Add("RedirectURL", RedirectURL.Text);

            datacollection.Add("Amount", amount.Text.ToString());

            //datacollection.Add("ResNum1", ""); // Ekhryari

            //datacollection.Add("ResNum2", "");// Ekhryari

            //datacollection.Add("ResNum3", "");// Ekhryari

            //datacollection.Add("ResNum4", "");// Ekhryari



            HttpHelper.RedirectAndPOST(this.Page, "https://sep.shaparak.ir/payment.aspx", datacollection);//

        }


        private int CreateResnum()
        {
            return (int)(DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds;
        }
    }
}