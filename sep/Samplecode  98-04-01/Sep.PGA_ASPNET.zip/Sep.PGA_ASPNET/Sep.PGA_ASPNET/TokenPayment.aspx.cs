﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Sep.PGA_ASPNET
{
    public partial class TokenPayment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
                ResNum.Text = CreateResnum().ToString();
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            var initPayment = new Sep.InitPayment.PaymentIFBinding();

            string token = initPayment.RequestToken(MID.Text, ResNum.Text, long.Parse(amount.Text), 0, 0, 0, 0, 0, 0, "", "", 0);

            // اگر عدد برگشت مانند -18 آی پی بسته است و.. به مستند مراجعه شود

            NameValueCollection datacollection = new NameValueCollection();

            datacollection.Add("Token", token);

            datacollection.Add("RedirectURL", RedirectURL.Text);

            HttpHelper.RedirectAndPOST(this.Page, "https://sep.shaparak.ir/payment.aspx", datacollection);//
        }

        private int CreateResnum()
        {
            return (int)(DateTime.Now - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds;
        }
    }
}