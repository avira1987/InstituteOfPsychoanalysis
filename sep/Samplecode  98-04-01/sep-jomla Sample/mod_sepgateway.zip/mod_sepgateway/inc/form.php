﻿ <?php 
 	        include_once('Sep.class.php');
			$Sep = new Sep;
			 $result = $Sep->getDBdata();
			 		
?>
<link rel="stylesheet" href="<?php echo JUri::root() ?>/modules/mod_sepgateway/inc/style.css" type="text/css" />
<div class="payment-form">
	<form action="https://sep.shaparak.ir/payment.aspx" method="post">
		<table width="100%">
			<tr>
				<td>نام</td>
				<td>
					<input type="text" name="payer_name" class="Sep-input" value=""/>
					<span class="description-require">*</span>
				</td>
			</tr>

			<tr>
				<td>ایمیل</td>
				<td>
					<input type="text" name="payer_email" dir="ltr" class="Sep-input" value=""/>
					<span class="description-require">*</span>
				</td>
			</tr>

			<tr>
				<td>شماره همراه</td>
				<td>
					<input type="text" name="payer_mobile" dir="ltr" value="09" class="Sep-input"/>
					<span class="description-require">*</span>
				</td>
			</tr>

			<tr>
				<td>مبلغ (ریال)</td>
				<td>
					<input type="text" name="Amount" dir="ltr" class="Sep-input"/>
					<span class="description-require">*</span>
					
						
				</td>
			</tr>	
			
			<tr>
				<td>شماره خرید</td>
				<td>
					<input type="text" name="ResNum" dir="ltr" class="Sep-input" value=''/>
					<span class="description-require">*</span>
				</td>
			</tr>

			<tr>
				<td colspan="2">
					<input type="submit" name="submit_payment" value="پرداخت" class="Sep-submit"/>
				</td>
			</tr>
		</table>

			<input type="hidden" name="RedirectURL" value="<?php if(isset($result[0])) echo $result[0]->ReturnURL ?>"/>
			<input type="hidden"  name="MID" value="<?php if(isset($result[0])) echo $result[0]->MID ?>"/>
	</form>
</div>

