<?php
/**
 * Sep
 *
 * Sep getway class
 *
 * @copyright	(c) 2015 Amin Rahimi
 * @author		Amin Rahimi <amin.ra20[at]gmail[dot]com>
 * @license		http://www.opensource.org/licenses/gpl-3.0.html
 * @version		1.0
 */
Class Sep {



	/**
	 * Parpal MerchantID
	 *
	 * @var integer
	 */
	public $MerchantID;

	/**
	 * Sep getway password
	 *
	 * @var integer
	 */
	public $Password;

	/**
	 * Sep price payment
	 *
	 * @var integer
	 */
	public $Price;

	/**
	 * Return URL in from Sep
	 *
	 * @var string
	 */
	public $ReturnPath;

	/**
	 * Receipt Number
	 *
	 * @var integer
	 */
	public $ResNumber;

	/**
	 * Tracking Number
	 *
	 * @var integer
	 */
	public $RefNumber;

	/**
	 * Description for payment operations
	 *
	 * @var string
	 */
	public $Description;

	/**
	 * Payer name
	 *
	 * @var string
	 */
	public $Paymenter;

	/**
	 * Email payer
	 *
	 * @var string
	 */
	public $Email;

	/**
	 * Mobile payer
	 *
	 * @var integer
	 */
	public $Mobile;

	/**
	 * Payment price
	 *
	 * @var integer
	 */
	public $PayPrice;

	/**
	 * Constructors
	 */
	public function __construct() {
		
	}
	
	
	/**
	 * getDBdata
	 *
	 * @param  Not param
	 * @return List of module setting
	 */
	public function getDBdata() {
		    //Obtain JDatabase static connection
		$oDb = JFactory::getDbo();
		$oQuery = $oDb->getQuery(true);
	
		$oQuery
        ->select(array('Id,MID,ReturnURL'))
        ->from('#__sepgateway')
        ->order('id ASC');

		$oDb->setQuery($oQuery);
		return $oDb->loadObjectList();	
	}
	/**
	 * Verify Payment
	 *
	 * @param  Not param
	 * @return Status verify
	 */
	public function Verify() {
		
		if(isset($_POST['State']) && $_POST['State'] == "OK") {				
					$soapclient = new soapclient('https://sep.shaparak.ir/Payments/ReferencePayment.asmx?WSDL');

					$res=  $soapclient->VerifyTransaction($_POST['RefNum'], $_POST['MID']);#reference number and sellerid
			return $res;
		}
	}
}