﻿<?php
/**
 * Helper class for Sep Gateway! module
 * 
 * @package    Sep gateway
 * @subpackage Modules
 * @link http://sep.ir
 * @license        GNU/GPL, see LICENSE.php
 * mod_sepgateway is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
class ModSepGatewayHelper
{
	
    public static function getForm($params)
    {
	    include_once('inc/form.php');

		$app = JFactory::getApplication();
		
		$postData = $app->input->post;

		$state = $postData->get('State', '', 'filter');
		
			include_once('inc/Sep.class.php');
			$Sep = new Sep;

		  if(empty($state))
		  {
		  
		  }else if($state!="OK")
		  {
			echo("<p class='error-payment'>عملیات ناموفق</p>");
		  }else{
				 $result=$Sep->Verify();
				 if( $result <= 0 ){
					 echo '<p class="error-payment">تراکنش تایید نشد</p>' ;
					 echo $result ;
					 echo '</p>';
				 }
				else
				{
					 echo '<p class="success-payment">تراکنش با موفقیت انجام شد<br/> مبلغ :';
					 echo $result ;
					 echo ' ریال</p>';
				 }
		  }		

        return '';
    }
}
?>