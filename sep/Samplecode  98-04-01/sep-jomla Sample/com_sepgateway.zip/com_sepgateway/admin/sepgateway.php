<?php
/**
 * @package     Sep.Gateway
 * @subpackage  com_sepgateway
 *
 * @copyright   Copyright (C) 2015 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die;

// Get an instance of the controller prefixed by SepGateway
$controller = JControllerLegacy::getInstance('SepGateway');

// Perform the Request task
$input = JFactory::getApplication()->input;
$controller->execute($input->getCmd('task'));

// Redirect if set by the controller
$controller->redirect();
