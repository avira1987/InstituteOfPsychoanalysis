<?php
/**
 * @package     Sep.Gateway
 * @subpackage  com_sepgateway
 *
 * @copyright   Copyright (C) 2015 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

/**
 * Hello Table class
 *
 * @since  0.0.1
 */
class SepGatewayTableSepGateway extends JTable
{
	/**
	 * Constructor
	 *
	 * @param   JDatabaseDriver  &$db  A database connector object
	 */
	function __construct(&$db)
	{
		parent::__construct('#__sepgateway', 'id', $db);
	}
}
