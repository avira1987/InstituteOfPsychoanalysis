<?php
/**
 * @package     Sep.Gateway
 * @subpackage  com_sepgateway
 *
 * @copyright   Copyright (C) 2015 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined('_JEXEC') or die;

?>
<form action="<?php echo JRoute::_('index.php?option=com_sepgateway&layout=edit&id=' . (int) $this->item->id); ?>"
    method="post" name="adminForm" id="adminForm">
    <div class="form-horizontal">
        <fieldset class="adminform">
            <legend><?php echo JText::_('COM_SEPGATEWAY_SEPGATEWAY_DETAILS'); ?></legend>
            <div class="row-fluid">
                <div class="span6">
                    <?php foreach ($this->form->getFieldset() as $field): ?>
                        <div class="control-group">
                            <div class="control-label"><?php echo $field->label; ?></div>
                            <div class="controls"><?php echo $field->input; ?></div>
                        </div>
                    <?php endforeach; ?>
                <div>
            <div>
        </fieldset>
    <div>
    <input type="hidden" name="task" value="sepgateway.edit" />
    <?php echo JHtml::_('form.token'); ?>
</form>
