DROP TABLE IF EXISTS `#__sepgateway`;

CREATE TABLE `#__sepgateway` (
	`id`       INT(11)     NOT NULL AUTO_INCREMENT,
	`ReturnURL` VARCHAR(4000) NOT NULL,
	`MID` VARCHAR(25) NOT NULL,
	`published` tinyint(4) NOT NULL,
	PRIMARY KEY (`id`)
)
	ENGINE =MyISAM
	AUTO_INCREMENT =0
	DEFAULT CHARSET =utf8;

INSERT INTO `#__sepgateway` (`ReturnURL`,`MID`) VALUES
('http://your_site_url/page','1000');
