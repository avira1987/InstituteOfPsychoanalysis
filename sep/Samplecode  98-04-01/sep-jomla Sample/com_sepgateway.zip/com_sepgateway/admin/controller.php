<?php
/**
 * @package     Sep.Gateway
 * @subpackage  com_sepgateway
 *
 * @copyright   Copyright (C) 2015 - 2016 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die;

/**
 * General Controller of SepGateway component
 *
 * @package     Sep.Gateway
 * @subpackage  com_sepgateway
 * @since       0.0.7
 */
class SepGatewayController extends JControllerLegacy
{
	/**
	 * The default view for the display method.
	 *
	 * @var string
	 * @since 12.2
	 */
	protected $default_view = 'sepgateways';
}
